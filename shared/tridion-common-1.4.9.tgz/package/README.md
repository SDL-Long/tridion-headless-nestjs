## Requirements

- Node.js (version 18.17.0 or higher)
- npm or Yarn package manager

## Configuration

Add the .env file with your configuration settings

## Getting Started

```bash

# install dependencies
npm install or npm install --legacy-peer-deps

# or
yarn ***
```


